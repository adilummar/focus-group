function redirectToFocusCafe(){
    window.location.href =  'focuscafe.html';
}

function redirectToFocusMart(){
    window.location.href =  'focusmart.html';
}

function redirectToPopIce(){
    window.location.href =  'focusmart.html';
}